<footer class="footer">
        <hr>
        <div class="container">
            <div class="row text-md-left text-center">
                <div class="col-sm-3">
                    <h2>Tisaurus</h2>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dicta ab autem assumenda ducimus
                        ipsum
                        provident temporibus labore</p>
                </div>
                <div class="col-sm-3">
                    <h2>Footer</h2>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                </div>
                <div class="col-sm-3">
                    <h2>Footer</h2>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                </div>
                <div class="col-sm-3">
                    <h2>Footer</h2>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                </div>
            </div>
            <hr>
            <div class="copyright">
                <p class="text-center">Copyright Tisaurus 2021</p>
            </div>
        </div>
    </footer>

   
</body>

</html>