<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>

    <!-- boostrap 4.6 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
        integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <!-- style.css -->
    <link rel="stylesheet" href="./style.css">

    <!-- font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,300;0,400;0,600;0,700;1,400;1,600;1,700&display=swap"
        rel="stylesheet">

</head>

<body>

    <nav class="navbar navbar-light justify-content-center">
        <h2 class="logo">Tisaurus</h2>

    </nav>
    <div class="container ">



        <!-- heading -->
        <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 col-sm-8">
                <h1 class="text-center display-4 judul">
                    Ensiklopedia Teknologi Informasi Indonesia
                </h1>


            </div>
        </div>

        <!-- form search -->
        <div class="row justify-content-center pencarian">
            <div class="col-lg-6">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Cari Istilah TI" aria-label="Istilah TI"
                        aria-describedby="istilah-ti">
                    <div class="input-group-append">
                        <button class="btn btn-outline-secondary" id="index-custom-search" type="button"
                            id="istilah-ti">Cari</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- konten tengah -->
        <!-- apa itu tisaurus -->
        <div class="row justify-content-center index-pembukaan">
            <div class="col-lg-8 text-center">
                <h2>Apa itu Tisaurus</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis impedit inventore praesentium,
                    molestiae incidunt amet expedita voluptatibus molestias quae, quam dolor est, soluta laudantium sint
                    vitae pariatur itaque ullam reprehenderit.</p>
            </div>
        </div>
        <!-- istilah populer -->
        <div class="row justify-content-center index-pembukaan">
            <div class="col-lg-8 text-center">
                <h2>Istilah TI yang Populer di 2021</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perspiciatis impedit inventore praesentium,
                    molestiae incidunt amet expedita voluptatibus molestias quae, quam dolor est, soluta laudantium sint
                    vitae pariatur itaque ullam reprehenderit.</p>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-sm-4 istilah-populer text-center">
                    <div class="bone">
                        <h2 class="diplay-5">1</h2>
                        <hr>
                        <h3 class="judul-istilah-populer">
                            Lorem Ipsum
                        </h3>
                        <hr>
                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Consectetur quaerat cumque, nam sed
                        </p>
                    </div>
                </div>
                <div class="col-sm-4 istilah-populer text-center">
                    <div class="bone">
                        <h2 class="diplay-5">2</h2>
                        <hr>
                        <h3 class="judul-istilah-populer">
                            Lorem Ipsum
                        </h3>
                        <hr>
                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Consectetur quaerat cumque, nam sed
                        </p>
                    </div>
                </div>
                <div class="col-sm-4 istilah-populer text-center">
                    <div class="bone">
                        <h2 class="diplay-5">3</h2>
                        <hr>
                        <h3 class="judul-istilah-populer">
                            Lorem Ipsum
                        </h3>
                        <hr>
                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Consectetur quaerat cumque, nam sed
                        </p>
                    </div>

                </div>
            </div>
        </div>


    </div>
    <footer class="footer">
        <hr>
        <div class="container">
            <div class="row text-md-left text-center">
                <div class="col-sm-3">
                    <h2>Tisaurus</h2>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dicta ab autem assumenda ducimus
                        ipsum
                        provident temporibus labore</p>
                </div>
                <div class="col-sm-3">
                    <h2>Footer</h2>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                </div>
                <div class="col-sm-3">
                    <h2>Footer</h2>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                </div>
                <div class="col-sm-3">
                    <h2>Footer</h2>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                    <a href="#" class="link">
                        lorem ipsum footer
                    </a>
                </div>
            </div>
            <hr>
            <div class="copyright">
                <p class="text-center">Copyright Tisaurus 2021</p>
            </div>
        </div>
    </footer>

    <!-- boostrap java script -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF"
        crossorigin="anonymous"></script>
</body>

</html>